Django Grappelli
================

**A jazzy skin for the Django admin interface**.

Grappelli is a grid-based alternative/extension to the `Django <http://www.djangoproject.com>`_ administration interface.

Code
----

https://github.com/sehmaschine/django-grappelli

Documentation
-------------

http://readthedocs.org/docs/django-grappelli/

Releases
--------

* Grappelli 2.4.0 (not yet released): Compatible with Django 1.4
* Grappelli 2.3.8 (April 2012): Compatible with Django 1.3