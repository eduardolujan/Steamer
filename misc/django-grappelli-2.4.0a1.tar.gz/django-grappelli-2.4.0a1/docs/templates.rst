.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _templates:

Templates
=========

.. versionadded:: 2.4

|grappelli| includes a Documentation about the HTML/CSS-Framework::

	/grappelli/grp-dom-documentation/

.. note::
	This is fairly new and will be improved with future releases.


