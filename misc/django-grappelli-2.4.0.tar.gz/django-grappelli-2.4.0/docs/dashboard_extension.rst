.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _dashboard_extension:

Extending the Dashboard
=======================

.. todo::
    Write docs about how to add bookmarks or custom menus.

