:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _releasenotes:

Grappelli 2.4.x Release Notes
=============================

**Grappelli 2.4.x is compatible with Django 1.4**.

Overview
--------

* The main change (compared with Grappelli 2.3.x) is that all CSS is based on Compass.

What's new in Grappelli 2.4.x
-----------------------------

* Compass-based CSS.

Deprecated in 2.3.x
-------------------

* ADMIN_MEDIA_PREFIX

A special thanks goes Maxime Haineault for his help and feedback.