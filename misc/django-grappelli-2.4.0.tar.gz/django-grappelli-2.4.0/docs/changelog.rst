:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _changelog:

Changelog
=========

2.4.0 (not yet released)
------------------------

* Compatibility with Django 1.4
* moved /static/grappelli/ to /static/admin/ (that´s needed because of using the static-tag)