.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _dashboard_layout:

Dashboard Layout
================

.. todo::
    Write docs about changing the default 3-column dashboard layout.

