.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _templates:

Templates
=========

.. todo::
    Write HTML/CSS docs, explaining the framework (Groups, Modules, Fields, ...) in order to write custom templates.


