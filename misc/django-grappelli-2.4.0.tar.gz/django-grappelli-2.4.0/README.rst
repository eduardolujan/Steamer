Django Grappelli
================

**A jazzy skin for the Django admin interface**.

Grappelli is a grid-based alternative/extension to the `Django <http://www.djangoproject.com>`_ administration interface.

Code
----

https://github.com/sehmaschine/django-grappelli

Documentation
-------------

http://readthedocs.org/docs/django-grappelli/

Releases
--------

The latest release is Grappelli 2.3.7 (February 11, 2011), which requires Django 1.3.