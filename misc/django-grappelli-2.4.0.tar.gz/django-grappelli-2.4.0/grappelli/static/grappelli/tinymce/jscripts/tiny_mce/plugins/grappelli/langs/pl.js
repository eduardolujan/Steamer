tinyMCE.addI18n("pl.grappelli",{
grappelli_adv_desc:"Pokaż/Ukryj zaawansowane menu",
grappelli_documentstructure_desc:"Pokaż/Ukryj strukturę dokumentu"
});
